<template>
  <div id="app">
    <router-view></router-view>
    <Footer />
  </div>
</template>

<script>
import Footer from './components/Footer.vue';

export default {
  components: {
    Footer,
  },
};
</script>

<style>
body {
  margin: 0;
  font-family: 'Arial', sans-serif;
}

#app {
  text-align: center;
  margin-top: 20px;
}
</style>
