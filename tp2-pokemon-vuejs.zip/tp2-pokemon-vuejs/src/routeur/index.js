import { createRouter, createWebHistory } from 'vue-router';
import Pokedex from '../components/Pokedex.vue';
import DetailsPokemon from '../components/DetailsPokemon.vue';

const routes = [
  {
    path: '/',
    name: 'Pokedex',
    component: Pokedex
  },
  {
    path: '/pokemon/:pokemonId',
    name: 'DetailsPokemon',
    component: DetailsPokemon,
    props: true
  },
  { path: '/', component: Pokedex },
  { path: '/pokemon/:id', name: 'pokemon-details', component: DetailsPokemon, props: true },
];

const router = createRouter({
  history: createWebHistory(),
  routes,
});

export default router;

