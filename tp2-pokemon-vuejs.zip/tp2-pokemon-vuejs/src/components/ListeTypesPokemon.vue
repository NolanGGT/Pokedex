<!-- ListeTypesPokemon.vue -->

<template>
  <div class="liste-types">
    <h2>Liste des Types de Pokémon</h2>
    <ul>
      <li v-for="(count, type) in typesCount" :key="type">
        {{ type }} : {{ count }}
      </li>
    </ul>
  </div>
</template>

<script>
export default {
  props: {
    pokemons: {
      type: Array,
      required: true,
    },
  },
  computed: {
    typesCount() {
      const typesCount = {};

      this.pokemons.forEach(pokemon => {
        const mainType = pokemon.apiTypes[0].name;
        typesCount[mainType] = (typesCount[mainType] || 0) + 1;
      });

      return typesCount;
    },
  },
};
</script>

<style scoped>
.liste-types {
  margin-bottom: 20px;
}

.liste-types h2 {
  text-align: center;
  margin-bottom: 10px;
}

.liste-types ul {
  list-style: none;
  padding: 0;
}

.liste-types li {
  margin-bottom: 5px;
}
</style>
