<template>
    <div class="pokemon-card">
      <div class="header" :style="{ backgroundColor: getTypeColor(pokemon.apiTypes[0].name) }">
        <h2>{{ pokemon.name }}</h2>
        <img :src="pokemon.image" alt="Pokemon" />
      </div>
      <div class="types">
        <div v-for="type in pokemon.apiTypes" :key="type.name" class="type-info">
          <img :src="type.image" :alt="type.name" />
          <span>{{ type.name }}</span>
        </div>
      </div>
    </div>
  </template>
  
  
  <script>
  export default {
    props: {
      pokemon: {
        type: Object,
        required: true,
      },
    },
    methods: {
      getTypeColor(type) {
        const typeColors = {
             Plante: '#78C850',
             Feu: '#F08030',
             Eau: '#6890F0',
             Insecte: '#A8B820',
            Vol: '#A890F0',
            Poison: '#A040A0',
            Normal: '#A8A878',
            Electrik: '#F8D030',
            Fée: '#EE99AC',
            Combat: '#C03028',
            Sol: '#E0C068',
            Roche: '#B8A038',
            Spectre: '#705898',
            Dragon: '#7038F8',
            Acier: '#B8B8D0',
            Glace: '#98D8D8',
            Psy: '#F85888',
            Ténèbres: '#705848',
        };
  
        return typeColors[type] || '#D0D0D0';
      },
    },
  };
  </script>
  
  <style scoped>
  .pokemon-card {
    display: flex;
    flex-direction: column;
    border: 1px solid #ccc;
    border-radius: 8px;
    margin: 10px;
    overflow: hidden;
  }
  
  .header {
    text-align: center;
    padding: 16px;
  }
  
  .header h2 {
    margin: 0;
  }
  
  .header img {
    max-width: 100%;
    height: auto;
  }
  
  .types {
    display: flex;
    flex-wrap: wrap;
    gap: 5px;
    padding: 10px;
  }
  
  .type-info {
    display: flex;
    align-items: center;
  }
  
  .type-info img {
    max-width: 20px;
    height: 20px;
    margin-right: 5px;
  }
  
  .type-info span {
    font-weight: bold;
  }
  </style>
  