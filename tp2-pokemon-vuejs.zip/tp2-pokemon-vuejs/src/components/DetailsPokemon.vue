<!-- DetailsPokemon.vue -->

<template>
  <div class="pokemon-card">
    <div v-if="error">
      <p>{{ error }}</p>
    </div>
    <div v-else-if="loading">
      <p>Loading...</p>
    </div>
    <div v-else>
      <div class="header">
        <h2>{{ pokemon.name }}</h2>
        <img :src="pokemon.image" :alt="pokemon.name" />
      </div>
      <div class="stats">
        <p>HP: {{ pokemon.stats.HP }}</p>
        <p>Attack: {{ pokemon.stats.attack }}</p>
        <p>Defense: {{ pokemon.stats.defense }}</p>
        <p>Special Attack: {{ pokemon.stats.special_attack }}</p>
        <p>Special Defense: {{ pokemon.stats.special_defense }}</p>
        <p>Speed: {{ pokemon.stats.speed }}</p>
      </div>
    </div>
  </div>
</template>

<script>
import axios from 'axios';

export default {
  props: {
    pokemonId: {
      type: Number,
      required: true,
    },
  },
  data() {
    return {
      loading: true,
      error: null,
      pokemon: null,
    };
  },
  mounted() {
    this.fetchPokemonDetails();
  },
  watch: {
    pokemonId: 'fetchPokemonDetails',
  },
  methods: {
    async fetchPokemonDetails() {
      try {
        const response = await axios.get(`https://pokebuildapi.fr/api/v1/pokemon/${this.pokemonId}`);
        this.pokemon = response.data;
      } catch (error) {
        this.error = `Error fetching Pokemon details: ${error.message} - Status: ${error.response.status}`;
      } finally {
        this.loading = false;
      }
    },
  },
};
</script>

<style scoped>
.pokemon-card {
  width: 300px;
  margin: 20px;
  border: 2px solid #ccc;
  border-radius: 10px;
  overflow: hidden;
}

.header {
  text-align: center;
  padding: 16px;
  background-color: #f0f0f0;
}

.header h2 {
  margin: 0;
}

.header img {
  max-width: 100%;
  height: auto;
}

.stats {
  padding: 16px;
}

.stats p {
  margin: 8px 0;
}
</style>
