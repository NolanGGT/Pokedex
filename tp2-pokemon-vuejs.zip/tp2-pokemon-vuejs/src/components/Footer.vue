<template>
    <footer class="footer">
      <p>{{ fullName }}</p>
      <p>Numéro de TP : {{ tpNumber }}</p>
    </footer>
  </template>
  
  <script>
  export default {
    data() {
      return {
        fullName: "Nolan GIGOT",
        tpNumber: "TPB",
      };
    },
  };
  </script>
  
  <style scoped>
  .footer {
    background-color: #333;
    color: #fff;
    text-align: center;
    padding: 10px;
    bottom: 0;
    width: 100%;
  }
  </style>
  