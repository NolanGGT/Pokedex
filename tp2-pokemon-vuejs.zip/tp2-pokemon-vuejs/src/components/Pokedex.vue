<template>
    <div class="pokedex">
      <ListeTypesPokemon :pokemons="pokemons" />
      <div class="controls">
        <h2>Liste de Pokemon</h2>
        <label for="pokemonCount">Nombre de Pokémon :</label>
        <input type="number" id="pokemonCount" v-model="desiredPokemonCount" @input="fetchPokemonData" />
      </div>
  
      <div class="pokemon-cards">
        <router-link v-for="pokemon in pokemons" :key="pokemon.name" :to="{ name: 'pokemon-details', params: { id: pokemon.id }, props: { pokemon: pokemon } }">
            <Pokemon :pokemon="pokemon" />
        </router-link>
      </div>
    </div>
  </template>
  
  <script>
  import axios from 'axios';
  import Pokemon from './Pokemon.vue';
  import ListeTypesPokemon from './ListeTypesPokemon.vue';
  
  export default {
    components: {
      Pokemon,
      ListeTypesPokemon,
    },
    data() {
      return {
        pokemons: [],
        desiredPokemonCount: 20,
      };
    },
    mounted() {
      this.fetchPokemonData();
    },
    methods: {
        async fetchPokemonData() {
        try {
            const response = await axios.get(`https://pokebuildapi.fr/api/v1/pokemon/limit/${this.desiredPokemonCount}`);
            this.pokemons = response.data;
        } catch (error) {
            console.error('Error fetching Pokemon data:', error);
        }
        },
    },
  };
  </script>
  
  <style scoped>
  .pokedex {
    margin-top: 20px;
    margin-left: 250px;
    margin-right: 250px;
    background-color: rgb(215, 215, 215);
  }
  
  .controls {
    text-align: center;
    margin-bottom: 20px;
  }
  
  .pokemon-cards {
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    gap: 10px;
  }
  </style>
  