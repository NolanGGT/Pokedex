import Pokedex from './Pokedex.vue'; 
<template>
  <div id="app">
    <Pokedex />
  </div>
</template>

<script>
import Pokedex from './components/Pokedex.vue';

export default {
  components: {
    Pokedex,
  },
};
</script>

<style>
/* Ajoutez des styles au besoin */
</style>
