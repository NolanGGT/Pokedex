<!-- DetailsPokemon.vue -->

<template>
  <div class="pokemon-card">
    <div v-if="loading">
      <p>rechargez la page</p>
    </div>
    <div v-else>
      <div class="header">
        <h2>{{ pokemon.name }}</h2>
        <img :src="pokemon.image" :alt="pokemon.name" />
      </div>
      <div class="stats">
        <p>HP: {{ pokemon.stats.HP }}</p>
        <p>Attack: {{ pokemon.stats.attack }}</p>
        <p>Defense: {{ pokemon.stats.defense }}</p>
        <p>Special Attack: {{ pokemon.stats.special_attack }}</p>
        <p>Special Defense: {{ pokemon.stats.special_defense }}</p>
        <p>Speed: {{ pokemon.stats.speed }}</p>
      </div>
    </div>
  </div>
</template>

<script>
import axios from 'axios';

export default {
  props: {
    pokemonId: {
      type: Number,
      required: true,
    },
  },
  data() {
    return {
      loading: true,
      error: null,
      pokemon: null,
    };
  },
  mounted() {
    this.fetchPokemonDetails();
  },
  watch: {
    pokemonId: 'fetchPokemonDetails',
  },
  methods: {
    async fetchPokemonDetails() {
      try {
        const response = await axios.get(`https://pokebuildapi.fr/api/v1/pokemon/${this.pokemonId}`);
        this.pokemon = response.data;
      } catch (error) {
        this.error = `Error fetching Pokemon details: ${error.message} - Status: ${error.response.status}`;
      } finally {
        this.loading = false;
      }
    },
  },
};
</script>

<style scoped>

.pokemon-card {
  width: 300px;
  margin: 20px;
  border: 2px solid #515151;
  border-radius: 10px;
  overflow: hidden;
  margin-left: 620px;
}

.header {
  text-align: center;
  padding: 16px;
  background-color: #e5e5e5;
  border: 1px solid #515151;
  border-radius: 1px;
}

.header h2 {
  margin: 0;
}

.header img {
  max-width: 100%;
  height: auto;
}

.stats {
  padding: 16px;
  border: 1px solid #515151;
  border-radius: 1px;
}

.stats p {
  margin: 8px 0;
}
</style>
